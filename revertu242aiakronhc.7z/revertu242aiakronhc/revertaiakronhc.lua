Hooks:PostHook(WeaponTweakData, "init", "ai_hcar_is_cool", function(self)
	self.hcar_crew.DAMAGE = 8.7
end)